 "root_module": {
            "resources": [
                {
                    "address": "aws_security_group.risk_test",
                    "mode": "managed",
                    "type": "aws_security_group",
                    "name": "risk_test",
                    "provider_name": "registry.terraform.io/hashicorp/aws",
                    "schema_version": 1,
                    "values": {
                        "description": "Test security group for Terraform Risk Analyzer",
                        "name_prefix": "risk-analyzer-test-",
                        "region": "ap-southeast-2",
                        "revoke_rules_on_delete": false,
                        "tags": {
                            "Environment": "dev",
                            "Name": "risk-analyzer-network-test",
                            "Purpose": "RiskAnalyzerTesting"
                        },
                        "tags_all": {
                            "Environment": "dev",
                            "ManagedBy": "Terraform",
                            "Name": "risk-analyzer-network-test",
                            "Owner": "Imran Haider",
                            "Project": "aws-iac-risk-engine",
                            "Purpose": "RiskAnalyzerTesting"
                        },
                        "timeouts": null,
                        "vpc_id": "vpc-0c34a550ddff39e56"
                    },
                    "sensitive_values": {
                        "egress": [],
                        "ingress": [],
                        "tags": {},
                        "tags_all": {}
                    },
                    "identity_schema_version": 0,
                    "identity": {
                        "account_id": null,
                        "id": null,
                        "region": null
                    }
                },
                {
                    "address": "yaws_vpc_securit_group_ingress_rule.test_https",
                    "mode": "managed",
                    "type": "aws_vpc_security_group_ingress_rule",
                    "name": "test_https",
                    "provider_name": "registry.terraform.io/hashicorp/aws",
                    "schema_version": 0,
                    "values": {
                        "cidr_ipv4": "0.0.0.0/0",
                        "cidr_ipv6": null,
                        "description": "Risk analyzer test HTTPS access",
                        "from_port": 443,
                        "ip_protocol": "tcp",
                        "prefix_list_id": null,
                        "referenced_security_group_id": null,
                        "region": "ap-southeast-2",
                        "tags": {
                            "Name": "risk-test-https"
                        },
                        "tags_all": {
                            "Environment": "dev",
                            "ManagedBy": "Terraform",
                            "Name": "risk-test-https",
                            "Owner": "Imran Haider",
                            "Project": "aws-iac-risk-engine"
                        },
                        "to_port": 443
                    },
                    "sensitive_values": {
                        "tags": {},
                        "tags_all": {}
                    }
                }
            ],
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
         